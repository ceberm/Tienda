<?php
require_once ('Model/Cliente_Model.php');
require_once ('Model/Transaccion_Model.php');

class Cliente_Controller{
    private $model_c;
    private $model_t;
    
    function __construct(){
        $this->model_c = new Cliente_Model();
        $this->model_t = new Transaccion_Model();
    }
    
    function index(){
        $title = "Clientes";
        $query=$this->model_c->get();
        require_once 'View/header.php';
            require_once 'View/index.php';
            require_once 'View/footer.php';
    }
    
    function cliente(){
        $data = NULL;
        if(isset($_REQUEST['Id_Cliente'])){
            $data = $this->model_c->getId($_REQUEST['Id_Cliente']);
        }
        
        $title= "Clientes";
        $query = $this->model_c->get();
        
        require_once 'View/header.php';
        require_once 'View/Cliente.php';
        require_once 'View/footer.php';
    }
    
    function guardarCliente(){
        $data['Id_Cliente'] = $_REQUEST['txt_id'];
        $data['Nombre'] = $_REQUEST['txt_nombre'];
        $data['Apellido1'] = $_REQUEST['txt_apellido1'];
        $data['Apellido2'] = $_REQUEST['txt_apellido2'];
        $data['Telefono'] = $_REQUEST['txt_telefono'];
        $data['Fecha_Nacimiento'] = $_REQUEST['dpk_fechaNacimiento'];
        $data['Fecha_Ingreso'] = $_REQUEST['dpk_fechaIngreso'];
        $data['Saldo_Puntos'] = $_REQUEST['txt_saldo'];
        $data['Estado'] = $_REQUEST['ddl_estado'];
        
        $_id= $_REQUEST['txt_id'];
        
        if ($_id > 0){
            $this->model_c->edit($data,$_id);
        }else{
            $this->model_c->add($data);
        }
        
        $this->model_c->add($data);
        
        header('Location: index.php');
        
    }
    
    function delete(){
        $_id = $_REQUEST['Id_Cliente'];
        $this->model_c->delete($_id);
        header('Location: index.php');
    }
}




?>