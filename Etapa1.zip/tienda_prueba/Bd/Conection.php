<?php
class conection{
    public static function getConection(){
        $mysqli = new mysqli('127.0.0.1', 'root', '', 'empresa');
        if ($mysqli->connect_error) {
            die('Connect Error (' . $mysqli->connect_errno . ') '
                    . $mysqli->connect_error);
        }
        echo 'Connection OK';
        return $mysqli;
    }
}
?>