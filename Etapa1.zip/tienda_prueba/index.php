<?php 
session_start();
   
  // Controlo si el usuario ya está logueado en el sistema.
  if(isset($_SESSION['email'])){
      
    require_once "Bd/Conection.php";
    $controller = "Cliente";

    if (!isset ( $_REQUEST['c'] ) ){
        require_once "Controller/$controller"."_Controller.php";
        $controller = ucwords($controller) . '_Controller';
        $controller = new $controller;
        $controller->index();


    }else{
        $controller = strtolower($_REQUEST['c']);
        $accion = isset($_REQUEST['a']) ? $_REQUEST['a'] : 'index';
        require_once "Controller/$controller"."_Controller.php";
        $controller = ucwords($controller) . '_Controller';
        $controller = new $controller;

        call_user_func(array($controller, $accion));
    }
  }else{
    // Si no está logueado lo redireccion a la página de login.
    header("HTTP/1.1 302 Moved Temporarily");
    header("Location: Login/index.html");
  }





?>

