

      <script type="text/javascript">
            
               $( function() {
                   $( "#dpk_fechaNacimiento" ).datepicker({dateFormat: 'yy-mm-dd'});
                   $( "#dpk_fechaIngreso" ).datepicker({dateFormat: 'yy-mm-dd'});
                   
                   
                        
                   if($('[name="txt_selected"]').val() =='A'){
                        $('[name="ddl_estado"] option:eq(1)').prop('selected', true);
                    }else{
                        $('[name="ddl_estado"] option:eq(2)').prop('selected', true);
                    }
                   
                    if($('[name="txt_id"]').val() !='0'){
                        $('[name="txt_id"]').attr("disabled", "disabled");
                    }
                   
                   
                   
                   
              } );
            
        </script>     

</body>
</html>