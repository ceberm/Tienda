<div class="container" style="margin-top:88px">

    <div class="jumbotron">
        <h2>Listado de Clientes</h2>
    </div>
    <div class="container">
        <a style="float:right;" href="index.php?c=cliente&a=cliente" class="btn btn-info btn-lg" type="button">Agregar Cliente</a><br><br>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Identificación</th>
                    <th>Nombre</th>
                    <th>Apellidos</th>
                    <th>Teléfono</th>
                    <th>Fecha de Ingreso</th>
                    <th>Fecha de Nacimiento</th>
                    <th>Saldo de Puntos</th>
                    <th>Estado</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($query as $data): ?>
                <tr>
                    <td><?php echo $data['Id_Cliente'] ?></td>
                    <td><?php echo $data['Nombre'] ?></td>
                    <td><?php echo $data['Apellido1']. ' '. $data['Apellido2'] ?></td>
                    <td><?php echo $data['Telefono'] ?></td>
                    <td><?php echo $data['Fecha_Ingreso'] ?></td>
                    <td><?php echo $data['Fecha_Nacimiento'] ?></td>
                    <td><?php echo $data['Saldo_Puntos'] ?></td>
                    <td><?php echo $data['Estado'] == 'A'?  'Activo': 'Inactivo' ?></td>
                    <td>
                        <a href="index.php?c=cliente&a=cliente&Id_Cliente=<?php echo $data['Id_Cliente'] ?>" class="btn btn-default" id="<?php echo $data['Id_Cliente']; ?>">Editar</a>
                        <a href="index.php?c=cliente&a=delete&Id_Cliente=<?php echo $data['Id_Cliente'] ?>" class="btn btn-danger" id="<?php echo $data['Id_Cliente']; ?>">Eliminar</a>
                        
                    </td>
                    <td></td>
                    <td></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>


