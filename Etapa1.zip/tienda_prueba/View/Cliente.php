<div class="container">
    <div class="jumboron"><h2>Registro de Clientes</h2></div>
    <div class="col-md-12">
        <div class="form-horizontal">
            <form action="index.php?c=cliente&a=guardarCliente" method="post">
                <input type="hidden" name="txt_id" value="<?php echo $data['Id_Cliente'] != 0? $data['Id_Cliente']:"0" ?>" >
                <input type="hidden" name="txt_selected" value="<?php echo $data['Estado']?>" >
                <div class="form-group">
                    <label class="col-sm-2 control-label" for="txt_id">Identificación</label>
                    <div class='col-sm-6'>
                        <input type="text" value="<?php echo $data['Id_Cliente'] ?>" class="form-control" name="txt_id">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label" for="txt_nombre">Nombre</label>
                    <div class='col-sm-6'>
                        <input type="text" value="<?php echo $data['Nombre'] ?>" class="form-control" name="txt_nombre">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label" for="txt_apellido1">Apellido Paterno</label>
                    <div class='col-sm-6'>
                        <input type="text" value="<?php echo $data['Apellido1'] ?>" class="form-control" name="txt_apellido1">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label" for="txt_apellido2">Apellido Materno</label>
                    <div class='col-sm-6'>
                        <input type="text" value="<?php echo $data['Apellido2'] ?>" class="form-control" name="txt_apellido2">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label" for="txt_telefono">Teléfono</label>
                    <div class='col-sm-6'>
                        <input type="text" value="<?php echo $data['Telefono'] ?>" class="form-control" name="txt_telefono">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label" for="dpk_fechaIngreso">Fecha de Ingreso</label>
                    <div class='col-sm-6'>
                        <input type="text" value="<?php echo $data['Fecha_Ingreso'] ?>" name="dpk_fechaIngreso" id="dpk_fechaIngreso" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label" for="dpk_fechaNacimiento">Fecha de Nacimiento</label>
                    <div class='col-sm-6'>
                        <input type="text" value="<?php echo $data['Fecha_Nacimiento'] ?>" name="dpk_fechaNacimiento" id="dpk_fechaNacimiento" class="form-control">
                    </div>
                </div>
                 <div class="form-group">
                    <label class="col-sm-2 control-label" for="txt_saldo">Puntos Acumulados</label>
                    <div class='col-sm-6'>
                        <input type="text" value="<?php echo $data['Saldo_Puntos'] ?>" class="form-control" name="txt_saldo">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-2 control-label" for="ddl_estado">Estado</label>
                    <div class='col-sm-6'>
                        <select name="ddl_estado" class="form-control">
                            <option value=""> -- Escoge uno -- </option>
                            <option value="A">Activado</option>
                            <option value="D">Desactivado</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div class='col-sm-offset-2 col-sm-10'>
                        <button type="submit" class="btn btn-default">Guardar</button>
                        <a href="index.php" class="btn btn-default">Cancelar</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


