<?php
class Cliente_Model{

    private $DB;
    private $clientes;
    
    function __construct(){
        $this->DB = Conection::getConection();
        $this->clientes = array();
    }
    
    function get(){
        $query = $this-> DB->query("SELECT * FROM cliente"); 
        while($fila = $query->fetch_assoc()){
            $this->clientes[] = $fila;
        }
        return $this->clientes;
    }
    
    function getId($_Id_Cliente){
        $query = $this-> DB->query("SELECT * FROM cliente WHERE Id_Cliente = $_Id_Cliente"); 
        while($fila = $query->fetch_assoc()){
            $this->clientes = $fila;
        }
        return $this->clientes;
    }
    
    function edit($data, $_id){
         $sql = "UPDATE cliente SET Id_Cliente = '".$data['Id_Cliente']."', 
         Nombre='".$data['Nombre']."', 
         Apellido1='".$data['Apellido1']."', 
         Apellido2='".$data['Apellido2']."', 
         Telefono='".$data['Telefono']."', 
         Fecha_Nacimiento='".$data['Fecha_Nacimiento']."', 
         Fecha_Ingreso='".$data['Fecha_Ingreso']."', 
         Saldo_Puntos='".$data['Saldo_Puntos']."', 
         Estado='".$data['Estado']."'
         WHERE Id_Cliente = $_id";
        mysqli_query($this->DB, $sql) or die('Error de SQL'.mysqli_error($this->DB));
    }
    
    function delete($_Id_Cliente){
         $query = $this->DB->query("DELETE FROM cliente WHERE Id_Cliente = $_Id_Cliente"); 
        
        //mysqli_query($this->DB, $query) or die('Error de SQL'.mysqli_error($this->DB));
    }
    
    function add($data){        
        $sql = "INSERT INTO cliente (Id_Cliente, Nombre, Apellido1, Apellido2, Telefono, Fecha_Nacimiento, Fecha_Ingreso, Saldo_Puntos, Estado) VALUES"."('".$data['Id_Cliente']."', '".$data['Nombre']."', '".$data['Apellido1']."', '".$data['Apellido2']."', '".$data['Telefono']."', '".$data['Fecha_Nacimiento']."', '".$data['Fecha_Ingreso']."', '".$data['Saldo_Puntos']."', '".$data['Estado']."')";
        
        mysqli_query($this->DB, $sql) or die('Error de SQL'.mysqli_error($this->DB));
    }
}
?>
