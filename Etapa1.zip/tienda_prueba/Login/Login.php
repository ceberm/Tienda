<?php
  session_start();
 
  $email = $_POST['email'];
  $password = $_POST['password'];
   
  if($email == 'email@dominio.com' && $password == '1234'){
    $_SESSION['email'] = $email;
      
    header("HTTP/1.1 302 Moved Temporarily");
    header("Location: ../index.php");
  }else{
    echo 'El email o password es incorrecto, <a href="index.html">vuelva a intenarlo</a>.<br/>';
  }
 
?>